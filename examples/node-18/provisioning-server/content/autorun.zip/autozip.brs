' This is an example script of how to use the roBrightPackage component to 
' auto-zip and auto-run a package on a BrightSign device.
' Instruction details see:
' https://docs.brightsign.biz/how-tos/create-install-an-autorunzip

Sub Main()
    version$ = "1.0.0"
    path$ = FindDestPath()
    if path$ = "unknown" then
        print "autozip: no mounted destination found, aborting"
        return
    end if
    source$ = FindSourcePath()
    if source$ = "unknown" then
        print "autozip: no mounted source with autorun.zip found, aborting"
        return
    end if
    package = CreateObject("roBrightPackage", source$ + "autorun.zip")
    ' package.SetPassword("test")
    package.Unpack(path$)
    package = 0
    CreateDirectory(path$ + "feed_cache")
    CreateDirectory(path$ + "feedPool")
    CreateDirectory(path$ + "brightsign-dumps")

    DeleteFile(path$ + "autozip.brs")
    DeleteFile(source$ + "autorun.zip")
    a = RebootSystem()
End Sub

Function FindDestPath()
    if not IsFirmwareValid() then
        return "SD:/"
    end if

    destinationPaths = GetStorageDevices(true)
    for each destination in destinationPaths
        if IsMounted(destination) then
            return destination
        end if
    next
    return "unknown"
End Function

Function FindSourcePath()
    if not IsFirmwareValid() then
        return "SD:/"
    end if

    sourcePaths = GetStorageDevices(false)
    for each source in sourcePaths
        if IsMounted(source) and CheckFile(source + "autorun.zip") then
            return source
        end if
    next
    return "unknown"
End Function

Function GetStorageDevices(reverse as Boolean) As Object

    devices = ["USB1:/","SD:/","SD2:/","SSD:/"]

    storageHotplug = CreateObject("roStorageHotplug")
    if FindMemberFunction(storageHotplug, "GetStorages") <> invalid then
        devices = storageHotplug.GetStorages()
    end if

    if reverse then
        devices = ReverseArray(devices)
    end if
    return devices

end Function

Function ReverseArray(arr as Object) As Object
    reversed = []
    for i = arr.count() - 1 to 0 step -1
        reversed.push(arr[i])
    next
    return reversed
End Function

Function IsMounted(path as String)
    if CreateObject("roStorageHotplug").GetStorageStatus(path).mounted then
        return true
    end if
    return false
End Function

Function IsFirmwareValid()
    di = CreateObject("roDeviceInfo")
    return di.FirmwareIsAtLeast("7.0.60")
End Function

Function CheckFile(path as String)
    file = CreateObject("roReadFile", path)
    if type(file) = "roReadFile" then
        return true
    end if
    return false
End Function